# Customer Churn – Data Cleaning

Cleans the raw customer churn dataset (605 rows) into an analysis-ready file (600 rows).

## Files
| File | Description |
|---|---|
| `data_cleaning.ipynb` | Jupyter Notebook – full cleaning workflow with documented decisions |
| `data/customer_churn_raw_v2.csv` | Original raw data |
| `data/customer_churn_clean.csv` | Cleaned output |
| `data/cleaning_log.csv` | Every cleaning decision, rows affected and reasoning |

## Cleaning decisions
| Issue | Rows | Decision | Reason |
|---|---|---|---|
| Exact duplicate records | 5 | Dropped | CustomerID must be unique |
| `TotalChargesINR` = `"unknown"` | 10 | Imputed as MonthlyCharges × Tenure (0 if tenure 0) | Actual/estimated ratio ≈ 0.98 across all complete rows |
| `MonthlyChargesINR` outliers | 7 | Divided by 12 and flagged | Annual amounts typed as monthly; ÷12 matches plan range and TotalCharges/Tenure |
| `Region` missing | 13 | Filled with `Unknown` | No reliable way to infer; avoids biasing regional churn |
| Headers / dtypes | all | snake_case, numeric types, `auto_pay` → bool, added `churn_flag` | Consistency |

## Run
```bash
pip install pandas numpy jupyter
jupyter notebook data_cleaning.ipynb
```
